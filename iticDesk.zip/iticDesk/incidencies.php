<?php
session_start();

if (!isset($_SESSION['user_login'])) {
    header("Location: login.php");
    exit;
}

$conn = mysqli_connect('localhost', 'alejandrom9', 'pirineus', 'alejandro_perez_iticdesk');

$email = $_SESSION['user_login'];
$sql = "SELECT * FROM incidencies WHERE usuari_email = '$email'";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html>
<head>
        <h1> <?php echo $_SESSION["rol"]; ?> </h1>
        <h1> <?php echo $_SESSION["nom"]; ?> </h1>

    <title>Incidencies</title>
</head>
<body>

    <h2>Incidències</h2>
    <?php
    if ($result && mysqli_num_rows($result) > 0) 
        while ($row = mysqli_fetch_assoc($result)) {
           
            echo "Número de Referència: " . $row["num_referencia"] . "<br>";
            echo "Prioritat: " . $row["estatprioritat"] . "<br>";
            echo "Títol: " . $row["titol"] . "<br>";
            echo "Descripció: " . $row["descripcio"] . "<br>";
            echo "Data: " . $row["data"] . "<br>";
            echo "Estat: " . "Desconegut" . "<br>";
            
    } 
    ?>

    
    <br>
    <a href="acces.php">Tornar</a>

</body>
</html>
